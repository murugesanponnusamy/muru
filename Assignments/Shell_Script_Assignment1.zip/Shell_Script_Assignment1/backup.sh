#!/bin/bash
backup_dir="backupDIR"
mkdir -p "$backup_dir"
for file in *.txt; do
    if [ -e "$file" ]; then
        cp "$file" "$backup_dir/"
    fi
done
echo "Backup Job completed."