#!/bin/bash
name="Murugesan"
echo "Hello, $name"
echo "Current date and time: $(date)"
