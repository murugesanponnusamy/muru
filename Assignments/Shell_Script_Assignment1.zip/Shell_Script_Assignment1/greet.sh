#!/bin/bash
echo -n "Enter your name::"
read username
echo "Hello, $username"
presentDIR=$(pwd)
echo "You are currently in $presentDIR"