#!/bin/bash
# Check if directory argument is provided
if [[ -z "$1" ]]; then
    echo "Usage: $0 <directory>"
    exit 1
fi
dir_path="$1"
# Check if the directory path exists
if [[ ! -d "$dir_path" ]]; then
    echo "Error: Directory path '$dir_path' does not exist."
    exit 1
fi
# Process each .txt file in parallel
for file in "$dir_path"/*.txt; do
    # Check if there are no .txt files
    [[ -e "$file" ]] || { echo "No .txt files found in '$dir_path'."; exit 0; }
    # Process file in the background
    {
        OUTPUT_FILE="${file%.txt}_processed.txt"
        tr '[:lower:]' '[:upper:]' < "$file" > "$OUTPUT_FILE"
        echo "Processed: $file -> $OUTPUT_FILE"
    } &
done
# Wait for all background processes to complete
wait
echo "All files processed successfully."