#!/bin/bash
# 1a. Check if both source file and destination are provided
if [[ $# -ne 2 ]]; then
    echo "Input format: $0 <source_file> <remote_user@host:/destination_path/>"
    exit 1
fi
source_file="$1"
destination="$2"


# 1b.Check if the source file exists
if [[ ! -f "$source_file" ]]; then
    echo "Error: Source file '$source_file' does not exist."
    exit 1
fi
# 2. Generate SHA-256 checksum of the file before transfer
local_checksum=$(sha256sum "$source_file" | awk '{print $1}')
echo "Local checksum: $local_checksum"

# 3.Transfer the file using SCP
scp "$source_file" "$destination"
if [[ $? -ne 0 ]]; then
    echo "Error: File transfer failed."
    exit 1
fi

# Extract remote path and filename
remote_host=$(echo "$destination" | cut -d':' -f1)
remote_path=$(echo "$destination" | cut -d':' -f2)
remote_file="$remote_path$(basename "$source_file")"

# 4. Generate remote SHA-256 checksum
remote_checksum=$(ssh -i key.pem "ec2-user@$remote_host" "sha256sum '$remote_file' 2>/dev/null | awk '{print \$1}'")


# 5. Compare checksums
if [[ "$local_checksum" == "$remote_checksum" ]]; then
    echo "Transfer successful."
else
    echo "File corrupted during transfer!"
fi