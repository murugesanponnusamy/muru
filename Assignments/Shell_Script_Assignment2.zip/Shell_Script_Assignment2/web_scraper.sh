#!/bin/bash
# Check if a URL is provided
if [[ -z "$1" ]]; then
    echo "Usage: $0 <URL>"
    exit 1
fi

URL="$1"
output_file="extracted_links.txt"

# Fetch webpage content using curl
webpage_content=$(curl -s "$URL")

# Extract links using grep and sed
echo "$webpage_content" | grep -oP '(?<=href=")[^"]*' > "$output_file"

# Display result
echo "Extracted links saved to $output_file."