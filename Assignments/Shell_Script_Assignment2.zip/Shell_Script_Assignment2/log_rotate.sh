#!/bin/bash
log_path="/var/log"
backup_path="./backup_logs"
# Check permission to access /var/log/
if [ ! -w "$log_path" ]; then
    log_path="./logs"
fi
mkdir -p "$backup_path"
# Find & compress logs older than 7 days
logs_found=$(find "$log_path" -name "*.log" -type f -mtime +7)
if [ -z "$logs_found" ]; then
    echo "No logs to rotate."
else
    find "$log_path" -name "*.log" -type f -mtime +7 -exec gzip {} \;
    find "$log_path" -name "*.log.gz" -type f -exec mv {} "$backup_path" \;
    echo "Log rotation finshed. Moved compressed logs to $backup_path."
fi