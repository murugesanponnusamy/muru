#!/bin/bash
logfile="/var/log/sys_monitor.log"
# Check permission to write to /var/log/
if [ ! -w "/var/log/" ]; then
    logfile="./sys_monitor.log"
fi
echo "Monitoring  CPU, MEM and Disk usage: $logfile"
i=0
while [ $i -lt 5 ]; do
    timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2 + $4}')
    mem_usage=$(free -m | awk 'NR==2{printf "%.2f", $3*100/$2 }')
    disk_usage=$(df -h / | awk 'NR==2 {print $5}')    
    echo "$timestamp - CPU: $cpu_usage% | Memory: $mem_usage% | Disk: $disk_usage" >> "$logfile"    
    if (( $(echo "$cpu_usage > 80" | bc -l) )); then
        echo "ALERT: CPU Usage exceeds 80% ($cpu_usage%)"
    fi    
    sleep 10
    ((i++))
done
echo " CPU, MEM and Disk usage monitoring completed."